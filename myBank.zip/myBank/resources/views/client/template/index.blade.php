@include('client.template.partials._head')
  <body style="background:#96D678;background-size: 100%">
    <!-- start navbar -->
    @include('client.template.partials._navbar')
    <!-- end navbar -->
    <!-- start content -->
    @include('client.template.partials._main')
    <!-- end content -->
  </body>
</html>