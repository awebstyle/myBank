@include('cashier.template.partials._head')

  <body style="background:#96D678;background-size: 100%">
    <!-- start navbar -->
    @include('cashier.template.partials._navbar')
    <!-- end navbar -->
    <!-- start content -->
    @include('cashier.template.partials._main')
    <!-- end content -->
  </body>
</html>