@include('admin.template.partials._head')
  <body style="background:#96D678;background-size: 100%">
    
    <!-- start navbar -->
    @include('admin.template.partials._navbar')
    <!-- end navbar -->

    <!-- start content -->
    @include('admin.template.partials._main')  
    <!-- end content -->

    
  </body>
</html>