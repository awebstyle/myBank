<?php $__env->startSection('title'); ?>
    Managment home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card w-100 text-center shadowBlue">
            <div class="card-header">
            All accounts
            </div>
            <?php if(Session::has('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(Session::get('status')); ?>

                </div>
            <?php endif; ?>
            <div class="card-body">
            <table class="table table-bordered table-sm bg-dark text-white">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Holder Name</th>
                    <th scope="col">Account No.</th>
                    <th scope="col">Branch Name</th>
                    <th scope="col">Current Balance</th>
                    <th scope="col">Account type</th>
                    <th scope="col">Contact</th>
                    <th scope="col">Actions</th>
                </tr>
                </thead>
                <tbody>
                    <input type="hidden" value="<?php echo e($i = 1); ?>">
                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($i); ?></th>
                            <td><?php echo e($account->name); ?></td>
                            <td><?php echo e($account->accountNumber); ?></td>
                            <td><?php echo e($account->branchName); ?></td>
                            <td>$<?php echo e($account->balance); ?></td>
                            <td><?php echo e($account->accountType); ?></td>
                            <td><?php echo e($account->phone); ?></td>
                            <td>
                            <a href="<?php echo e(route('adminshowaccount', [$account->id])); ?>" class='btn btn-success btn-sm' data-toggle='tooltip' title="View More info">View</a>
                            <a href="<?php echo e(route('adminnotice', [$account->id])); ?>" class='btn btn-primary btn-sm' data-toggle='tooltip' title="Send notice to this">Send Notice</a>
                            <a href="<?php echo e(route('admindeleteaccount', [$account->id])); ?>" class='btn btn-danger btn-sm' data-toggle='tooltip' title="Delete this account">Delete</a>
                            </td>
                        </tr>
                        <input type="hidden" value="<?php echo e($i++); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            </div>
            <div class="card-footer text-muted">
            MCB Bank  
            </div>
        </div>
        </div>
   
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('.admin.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/admin/home.blade.php ENDPATH**/ ?>