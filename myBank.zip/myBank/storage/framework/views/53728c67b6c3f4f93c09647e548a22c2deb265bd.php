<?php $__env->startSection('title'); ?>
    Client account
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="card  w-75 mx-auto">
        <div class="card-header text-center">
          Your account Information
        </div>
        <div class="card-body">
          <div class="text-center">
              <img src="/storage/account_images/<?php echo e($account->photo); ?>" height="150" width="150" alt="" class="rounded-circle m-2" style="border : 5px solid #555;">
          </div>
          <table class="table table-striped table-dark w-75 mx-auto">
            <thead>
              <tr>
                <td scope="col">Account No.</td>
                <th scope="col"><?php echo e($account->accountNumber); ?></th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th scope="row">Branch</th>
                <td><?php echo e($account->branchName); ?></td>
              </tr>
              <tr>
                <th scope="row">Branch Code</th>
                <td>100101</td>
              </tr>
              <tr>
                <th scope="row">Account Type</th>
                <td><?php echo e($account->branchCode); ?></td>
              </tr>
              <tr>
                <th scope="row">Account Created</th>
                <td><?php echo e($account->created_at); ?></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="card-footer text-muted">
            MCB Bank  
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/client/account.blade.php ENDPATH**/ ?>