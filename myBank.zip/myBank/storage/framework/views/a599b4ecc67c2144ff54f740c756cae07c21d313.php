<?php $__env->startSection('title'); ?>
    Client details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="card w-100 text-center shadowBlue">
        <div class="card-header">
          Account profile for <?php echo e($account->name); ?><kbd><?php echo e($account->accountNumber); ?></kbd>  
        </div>
        <div class="card-body bg-dark text-white">
          <div class="text-center">
            <img src="/storage/account_images/<?php echo e($account->photo); ?>" height="100" width="100" alt="" class="rounded-circle m-2" style="border : 2px solid #FFF;">
          </div>
          <table class="table table-bordered">
            <tbody>
              <tr>
                <td>Name</td>
                <th><?php echo e($account->name); ?></th>
                <td>Account No</td>
                <th><?php echo e($account->accountNumber); ?></th>
              </tr><tr>
                <td>Branch Name</td>
                <th><?php echo e($account->branchName); ?></th>
                <td>Branch Code</td>
                <th><?php echo e($account->branchCode); ?></th>
              </tr><tr>
                <td>Current Balance</td>
                <th>$ <?php echo e($account->balance); ?></th>
                <td>Account Type</td>
                <th><?php echo e($account->accountType); ?></th>
              </tr><tr>
                <td>Cnic</td>
                <th><?php echo e($account->cmic); ?></th>
                <td>City</td>
                <th><?php echo e($account->city); ?></th>
              </tr><tr>
                <td>Contact Number</td>
                <th><?php echo e($account->phone); ?></th>
                <td>Address</td>
                <th><?php echo e($account->address); ?></th>
              </tr>
            </tbody>
          </table>
        </div>
        <div class="card-footer text-muted">
          MCB Bank  
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/admin/showAccount.blade.php ENDPATH**/ ?>