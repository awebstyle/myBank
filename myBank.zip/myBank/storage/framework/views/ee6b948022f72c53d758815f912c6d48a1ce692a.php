<?php $__env->startSection('title'); ?>
    Feedback
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
      <div class="card  w-75 mx-auto">
        <div class="card-header text-center">
          Help Card
        </div>
        <?php if(Session::has('status')): ?>
        <div class="alert alert-success">
          <?php echo e(Session::get('status')); ?>

        </div>
        <?php endif; ?>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('clientmessage')); ?>">
              <?php echo csrf_field(); ?>
                <div class="alert alert-success w-50 mx-auto">
                  <h5>Enter your message</h5>
                  <textarea class="form-control" name="message" required placeholder="Write your message"></textarea>
                  <button type="submit" name="send" class="btn btn-primary btn-block btn-sm my-1">Send</button>
                </div>
            </form>
          <br>
        </div>
        <div class="card-footer text-muted">
        MCB Bank  
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/client/feedback.blade.php ENDPATH**/ ?>