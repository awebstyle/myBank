<?php echo $__env->make('client.template.partials._head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <body style="background:#96D678;background-size: 100%">
    <!-- start navbar -->
    <?php echo $__env->make('client.template.partials._navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end navbar -->
    <!-- start content -->
    <?php echo $__env->make('client.template.partials._main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end content -->
  </body>
</html><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/client/template/index.blade.php ENDPATH**/ ?>