<?php $__env->startSection('title'); ?>
    Client statements
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="card  w-75 mx-auto">
        <div class="card-header text-center">
          Transaction made against you account
        </div>
        <div class="card-body">
          <?php $__currentLoopData = $statements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($statement->source == Session::get('client')->accountNumber): ?>
              <?php if($statement->status == 0): ?>
                <div class="alert alert-success">
                 

                  Dépôt de $<?php echo e($statement->amount); ?> le <?php echo e(\Carbon\Carbon::parse($statement->created_at)->format('d/m/Y')); ?>

                </div>
              
              <?php elseif($statement->status == 1): ?>
                 <div class="alert alert-primary">
                  Transfert de $<?php echo e($statement->amount); ?> vers le compte <?php echo e($statement->destination); ?> le <?php echo e(\Carbon\Carbon::parse($statement->created_at)->format('d/m/Y')); ?>

                 </div>
              
              <?php elseif($statement->status == 3): ?>
                <div class="alert alert-warning">
                  Vous avez retiré $<?php echo e($statement->amount); ?> le <?php echo e(\Carbon\Carbon::parse($statement->created_at)->format('d/m/Y')); ?>

                </div>
              <?php endif; ?>
            <?php elseif($statement->destination == Session::get('client')->accountNumber): ?>
                <?php if($statement->status == 2): ?>
                  <div class="div alert alert-success">
                    Versement de $<?php echo e($statement->amount); ?> du compte <?php echo e($statement->source); ?> le <?php echo e(\Carbon\Carbon::parse($statement->created_at)->format('d/m/Y')); ?>

                  </div>
                <?php endif; ?>
            <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="card-footer text-muted">
        MCB Bank  
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/client/statements.blade.php ENDPATH**/ ?>