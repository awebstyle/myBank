<?php $__env->startSection('title'); ?>
    Manager Feedback
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="card w-100 text-center shadowBlue">
        <div class="card-header">
          Feedback from Account Holder
        </div>
        <?php if(Session::has('status')): ?>
          <div class="alert alert-success">
            <?php echo e(Session::get('status')); ?>

          </div>
        <?php endif; ?>
        <div class="card-body">
          <table class="table table-bordered table-sm bg-dark text-white">
            <thead>
              <tr>
                <th scope="col">From</th>
                <th scope="col">Account No.</th>
                <th scope="col">Contact</th>
                <th scope="col">Message</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($message->name); ?></td>
                  <td><?php echo e($message->accountNumber); ?></td>
                  <td><?php echo e($message->phone); ?></td>
                  <td><?php echo e($message->message); ?></td>
                  <td>
                    <a href="<?php echo e(route('deleteclientmessage', [$message->id])); ?>" class='btn btn-danger btn-sm' data-toggle='tooltip' title="Delete this Message">Delete</a>
                  </td> 
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
        <div class="card-footer text-muted">
          MCB Bank  
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/admin/feedback.blade.php ENDPATH**/ ?>