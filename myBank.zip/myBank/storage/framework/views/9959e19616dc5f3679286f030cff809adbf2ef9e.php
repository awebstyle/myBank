<?php $__env->startSection('title'); ?>
    Management accounts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <div class="card w-100 text-center shadowBlue">
        <div class="card-header">
          All Staff Accounts <button class="btn btn-outline-success btn-sm float-right" data-toggle="modal" data-target="#exampleModal">Add New Account</button>
        </div>

        <div class="card-body bg-dark text-white">
          <?php if(Session::has('status')): ?>
            <div class="alert alert-success">
              <?php echo e(Session::get('status')); ?>

            </div>
          <?php endif; ?>
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>Email</th>
                <th>Account Type</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($cashier->email); ?></td>
                 
                  <td><?php echo e($cashier->accounttype); ?></td>
                  <td class="d-flex justify-content-around">
                    <a href='' class='btn btn-primary btn-sm' data-toggle="modal" data-target="#exampleModalUpdate<?php echo e($cashier->id); ?>">Edit</a>
                    <form style="max-width: 25%;" action="<?php echo e(route('deletecashier', [$cashier->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field("DELETE"); ?>
                            <button type="submit" id="delete" class="btn btn-danger btn-sm" value="">Delete</button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </tbody>
          </table>
        </div>
        <div class="card-footer text-muted">
          MCB Bank  
        </div>
      </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content bg-dark text-white">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">New Cashier Account</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form method="POST" action=<?php echo e(route('addcashier')); ?>>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <input class="form-control w-75 mx-auto" type="email" name="email" required placeholder="Email">
                </div>
                <div class="form-group">
                  <input class="form-control w-75 mx-auto" type="password" name="password" required placeholder="Password" minlength="8">
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" name="saveAccount" class="btn btn-primary">Save Account</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal Update -->
    <?php $__currentLoopData = $cashiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="modal fade" id="exampleModalUpdate<?php echo e($cashier->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content bg-dark text-white">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Edit Cashier Account</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form method="POST" action="<?php echo e(route('updatecashier' , [$cashier->id])); ?>">
                <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" id="id" value= <?php echo e($cashier->id); ?>>
                  <div class="form-group">
                    <input class="form-control w-75 mx-auto" type="email" name="email" required placeholder="Email" value="<?php echo e($cashier->email); ?>">
                  </div>
                  <div class="form-group">
                    <input class="form-control w-75 mx-auto" type="password" name="password" required placeholder="Password" value="<?php echo e($cashier->password); ?>" minlength="8">
                  </div>
                  <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" name="saveAccount" class="btn btn-primary">Update Account</button>
                  </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/admin/accounts.blade.php ENDPATH**/ ?>