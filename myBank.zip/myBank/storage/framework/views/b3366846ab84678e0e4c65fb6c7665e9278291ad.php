<!DOCTYPE html>
<html>
  <head>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset("assets/css/bootstrap.min.css")); ?>>
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset("assets/css/custom.css")); ?>>
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset("assets/font-awesome/css/font-awesome.min.css")); ?>>
    <script src=<?php echo e(asset('assets/js/jquery-3.2.1.min.js')); ?>></script>
    <script src=<?php echo e(asset('assets/js/popper.min.js')); ?>></script>
    <script src=<?php echo e(asset('assets/js/bootstrap.min.js')); ?>></script>
    <script type="text/javascript">
      $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    });
    </script>    
  </head><?php /**PATH /Applications/MAMP/htdocs/udemy_laravel/myBank/myBank/resources/views/client/template/partials/_head.blade.php ENDPATH**/ ?>